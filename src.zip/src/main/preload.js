const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  openRefrensi: (filename) => ipcRenderer.send('open-refrensi', filename)
});