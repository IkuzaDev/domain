const { ipcRenderer } = require('electron');

document.addEventListener('DOMContentLoaded', () => {
  updateCurrentDate();
  setupEventListeners();
  loadInitialData();
});

function updateCurrentDate() {
  const now = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const dateString = now.toLocaleDateString('id-ID', options);
  document.getElementById('current-date').textContent = dateString;
}

function setupEventListeners() {
  const presdikBtn = document.getElementById('presdik-btn');
  const nilaitpBtn = document.getElementById('nilaitp-btn');
  const propela1Btn = document.getElementById('propela1-btn');
  const catatan1Btn = document.getElementById('catatan1-btn');

  if (presdikBtn) {
    presdikBtn.addEventListener('click', async () => {
      try {
        await ipcRenderer.invoke('open-presdik');
        showSuccessNotification('Jendela PESDIK berhasil dibuka!');
      } catch (error) {
        showErrorNotification('Gagal membuka jendela PESDIK: ' + error.message);
      }
    });
  }

  if (nilaitpBtn) {
    nilaitpBtn.addEventListener('click', () => {
      try {
        // Berpindah halaman ke nilaitp.html tanpa membuka window baru
        document.getElementById('nilaitp-btn').addEventListener('click', () => {
            ipcRenderer.send('open-refrensi', "n.html");
        });
      } catch (error) {
        showErrorNotification('Gagal berpindah ke halaman NILAI & TPF: ' + error.message);
      }
    });
  }

  if (propela1Btn) {
    propela1Btn.addEventListener('click', async () => {
      try {
        await ipcRenderer.invoke('open-propela');
        showSuccessNotification('Jendela PROPELA 1 berhasil dibuka!');
      } catch (error) {
        showErrorNotification('Gagal membuka jendela PROPELA 1: ' + error.message);
      }
    });
  }

  if (catatan1Btn) {
    catatan1Btn.addEventListener('click', async () => {
      try {
        await ipcRenderer.invoke('open-catatan');
        showSuccessNotification('Jendela CATATAN 1 berhasil dibuka!');
      } catch (error) {
        showErrorNotification('Gagal membuka jendela CATATAN 1: ' + error.message);
      }
    });
  }

  // Mapel buttons
  const mapelButtons = {
    'mapel-mtk-btn': 'MTK',
    'mapel-bindo-btn': 'BINDO',
    'mapel-binggris-btn': 'BINGGRIS',
    'mapel-pkn-btn': 'PKN',
    'mapel-ips-btn': 'IPS',
    'mapel-sbd-btn': 'SBD',
    'mapel-pjok-btn': 'PJOK',
    'mapel-agama-btn': 'AGAMA',
    'mapel-mulok-btn': 'MULOK'
  };

  Object.entries(mapelButtons).forEach(([buttonId, mapelKode]) => {
    const button = document.getElementById(buttonId);
    if (button) {
      button.addEventListener('click', async () => {
        try {
          const result = await ipcRenderer.invoke('open-mapel', mapelKode);
          if (result.success) {
            showSuccessNotification(`Jendela ${mapelKode} berhasil dibuka!`);
          } else {
            showErrorNotification(`Gagal membuka jendela ${mapelKode}: ${result.error}`);
          }
        } catch (error) {
          showErrorNotification(`Gagal membuka jendela ${mapelKode}: ${error.message}`);
        }
      });
    }
  });

  const navButtons = document.querySelectorAll('nav button, nav a');
  navButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      const buttonId = e.target.id;
      if (!buttonId || !['presdik-btn', 'nilaitp-btn', 'propela1-btn', 'catatan1-btn'].includes(buttonId)) {
        e.preventDefault();
        showInfoNotification('Fitur ini akan segera tersedia!');
      }
    });
  });
}

async function loadInitialData() {
  try {
    const mapelResult = await ipcRenderer.invoke('get-mapel-data');
    if (mapelResult.success) {
      console.log('Mapel data loaded:', mapelResult.data);
    } else {
      console.error('Failed to load mapel data:', mapelResult.error);
    }

    const sekolahResult = await ipcRenderer.invoke('get-sekolah-data');
    if (sekolahResult.success) {
      console.log('Sekolah data loaded:', sekolahResult.data);
    } else {
      console.error('Failed to load sekolah data:', sekolahResult.error);
    }

    // Validasi integrasi HTML
    await validateHTMLIntegration();
  } catch (error) {
    console.error('Error loading initial data:', error);
  }
}

async function validateHTMLIntegration() {
  try {
    const validation = await ipcRenderer.invoke('validate-html-integration');
    if (validation.success) {
      const { mapelFiles, mainFiles, errors } = validation.data;
      
      console.log('HTML Integration Validation:');
      console.log('Mapel Files:', mapelFiles.length);
      console.log('Main Files:', mainFiles.length);
      
      if (errors.length > 0) {
        console.error('Integration Errors:', errors);
        showErrorNotification(`Ditemukan ${errors.length} masalah integrasi HTML`);
      } else {
        console.log('✅ Semua file HTML terintegrasi dengan baik');
        showSuccessNotification('Integrasi HTML berhasil!');
      }
    } else {
      console.error('Validation failed:', validation.error);
    }
  } catch (error) {
    console.error('Error validating HTML integration:', error);
  }
}

async function loadMapelFiles() {
  try {
    const result = await ipcRenderer.invoke('get-all-mapel-files');
    if (result.success) {
      console.log('Mapel files loaded:', result.data);
      return result.data;
    } else {
      console.error('Failed to load mapel files:', result.error);
      return [];
    }
  } catch (error) {
    console.error('Error loading mapel files:', error);
    return [];
  }
}

async function loadMainFiles() {
  try {
    const result = await ipcRenderer.invoke('get-main-files');
    if (result.success) {
      console.log('Main files loaded:', result.data);
      return result.data;
    } else {
      console.error('Failed to load main files:', result.error);
      return [];
    }
  } catch (error) {
    console.error('Error loading main files:', error);
    return [];
  }
}

async function saveNilaiFromHTML(mapelKode, siswaId, nilaiData) {
  try {
    const result = await ipcRenderer.invoke('save-nilai-from-html', {
      mapelKode,
      siswaId,
      nilaiData
    });
    
    if (result.success) {
      showSuccessNotification(`Nilai ${mapelKode} berhasil disimpan`);
      return result.data;
    } else {
      showErrorNotification(`Gagal menyimpan nilai ${mapelKode}: ${result.error}`);
      return null;
    }
  } catch (error) {
    console.error('Error saving nilai from HTML:', error);
    showErrorNotification('Error menyimpan nilai');
    return null;
  }
}

async function getNilaiByMapelAndSiswa(mapelKode, siswaId) {
  try {
    const result = await ipcRenderer.invoke('get-nilai-by-mapel-and-siswa', {
      mapelKode,
      siswaId
    });
    
    if (result.success) {
      return result.data;
    } else {
      console.error('Failed to get nilai:', result.error);
      return null;
    }
  } catch (error) {
    console.error('Error getting nilai:', error);
    return null;
  }
}

async function getAllNilaiBySiswa(siswaId) {
  try {
    const result = await ipcRenderer.invoke('get-all-nilai-by-siswa', siswaId);
    if (result.success) {
      return result.data;
    } else {
      console.error('Failed to get all nilai:', result.error);
      return [];
    }
  } catch (error) {
    console.error('Error getting all nilai:', error);
    return [];
  }
}

// Fungsi untuk menampilkan status integrasi di UI
function displayIntegrationStatus() {
  const statusContainer = document.createElement('div');
  statusContainer.id = 'integration-status';
  statusContainer.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg z-50';
  statusContainer.innerHTML = `
    <div class="flex items-center">
      <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
      </svg>
      <span>Database Terintegrasi</span>
    </div>
  `;
  
  document.body.appendChild(statusContainer);
  
  // Hilangkan setelah 5 detik
  setTimeout(() => {
    if (statusContainer.parentNode) {
      statusContainer.parentNode.removeChild(statusContainer);
    }
  }, 5000);
}

function showSuccessNotification(message) {
  Swal.fire({
    icon: 'success',
    title: 'Berhasil!',
    text: message,
    timer: 2000,
    timerProgressBar: true,
    toast: true,
    position: 'top-end',
    showConfirmButton: false
  });
}

function showErrorNotification(message) {
  Swal.fire({
    icon: 'error',
    title: 'Error!',
    text: message,
    timer: 3000,
    timerProgressBar: true,
    toast: true,
    position: 'top-end',
    showConfirmButton: false
  });
}

function showInfoNotification(message) {
  Swal.fire({
    icon: 'info',
    title: 'Informasi',
    text: message,
    timer: 2500,
    timerProgressBar: true,
    toast: true,
    position: 'top-end',
    showConfirmButton: false
  });
}

function showConfirmDialog(title, text, callback) {
  Swal.fire({
    title: title,
    text: text,
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ya',
    cancelButtonText: 'Tidak'
  }).then((result) => {
    if (result.isConfirmed && callback) {
      callback();
    }
  });
}

function animateElement(element, animationClass) {
  element.classList.add(animationClass);
  setTimeout(() => {
    element.classList.remove(animationClass);
  }, 1000);
}

function addHoverEffects() {
  const interactiveElements = document.querySelectorAll('button, a, .interactive');
  interactiveElements.forEach(element => {
    element.addEventListener('mouseenter', () => {
      element.style.transform = 'scale(1.02)';
      element.style.transition = 'transform 0.2s ease';
    });
    
    element.addEventListener('mouseleave', () => {
      element.style.transform = 'scale(1)';
    });
  });
}

function setupKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'p') {
      e.preventDefault();
      document.getElementById('presdik-btn').click();
    }
    if (e.ctrlKey && e.key === 'n') {
      e.preventDefault();
      document.getElementById('nilaitp-btn').click();
    }
    if (e.ctrlKey && e.key === 'r') {
      e.preventDefault();
      document.getElementById('propela1-btn').click();
    }
    if (e.ctrlKey && e.key === 'c') {
      e.preventDefault();
      document.getElementById('catatan1-btn').click();
    }
  });
}

window.addEventListener('load', () => {
  addHoverEffects();
  setupKeyboardShortcuts();
  
  const elements = document.querySelectorAll('.fade-in, .slide-in');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  });
  
  elements.forEach(element => {
    observer.observe(element);
  });
}); 