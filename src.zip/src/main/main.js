const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const Database = require('../database/database');

let mainWindow;
let presdikWindow;
let nilaitpWindow;
let propelaWindow;
let catatanWindow;
let db;

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 850,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    icon: path.join(__dirname, '../../assets/icon.png'),
    show: false,
    titleBarStyle: 'default'
  });

  mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function createPresdikWindow() {
  if (presdikWindow) {
    presdikWindow.focus();
    return;
  }

  presdikWindow = new BrowserWindow({
    width: 1600,
    height: 1000,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    parent: mainWindow,
    modal: false,
    show: false
  });

  presdikWindow.loadFile(path.join(__dirname, '../../refrensi/presdik.html'));

  presdikWindow.once('ready-to-show', () => {
    presdikWindow.show();
  });

  presdikWindow.on('closed', () => {
    presdikWindow = null;
  });
}

function createNilaiTpWindow() {
  if (nilaitpWindow) {
    nilaitpWindow.focus();
    return;
  }

  nilaitpWindow = new BrowserWindow({
    width: 1100,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    parent: mainWindow,
    modal: false,
    show: false
  });

  nilaitpWindow.loadFile(path.join(__dirname, '../../refrensi/n.html'));

  nilaitpWindow.once('ready-to-show', () => {
    nilaitpWindow.show();
  });

  nilaitpWindow.on('closed', () => {
    nilaitpWindow = null;
  });
}

function createPropelaWindow() {
  if (propelaWindow) {
    propelaWindow.focus();
    return;
  }

  propelaWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    parent: mainWindow,
    modal: false,
    show: false
  });

  propelaWindow.loadFile(path.join(__dirname, '../../refrensi/propela.html'));

  propelaWindow.once('ready-to-show', () => {
    propelaWindow.show();
  });

  propelaWindow.on('closed', () => {
    propelaWindow = null;
  });
}

function createCatatanWindow() {
  if (catatanWindow) {
    catatanWindow.focus();
    return;
  }

  catatanWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    parent: mainWindow,
    modal: false,
    show: false
  });

  catatanWindow.loadFile(path.join(__dirname, '../../refrensi/catatan.html'));

  catatanWindow.once('ready-to-show', () => {
    catatanWindow.show();
  });

  catatanWindow.on('closed', () => {
    catatanWindow = null;
  });
}

app.whenReady().then(async () => {
  db = new Database();
  await db.initialize();
  
  createMainWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

ipcMain.handle('open-presdik', () => {
  createPresdikWindow();
});

ipcMain.handle('open-nilaitp', () => {
  createNilaiTpWindow();
});

ipcMain.handle('open-propela', () => {
  createPropelaWindow();
});

ipcMain.handle('open-catatan', () => {
  createCatatanWindow();
});

ipcMain.on('open-refrensi', (event, filename) => {
    mainWindow.loadFile(path.join(__dirname, '../../refrensi', filename));
});

// IPC handler untuk membuka file mapel
ipcMain.handle('open-mapel', async (event, mapelKode) => {
  try {
    const mapelData = {
      'MTK': { nama: 'Matematika', file: 'mtk.html', color: '#e0f7fa' },
      'BINDO': { nama: 'Bahasa Indonesia', file: 'bindo.html', color: '#e3f2fd' },
      'BINGGRIS': { nama: 'Bahasa Inggris', file: 'bInggris.html', color: '#e8f5e8' },
      'PKN': { nama: 'Pendidikan Kewarganegaraan', file: 'pkn.html', color: '#e0f2f1' },
      'IPS': { nama: 'Ilmu Pengetahuan Sosial', file: 'Ips.html', color: '#fff3e0' },
      'SBD': { nama: 'Seni Budaya', file: 'sbd.html', color: '#fce4ec' },
      'PJOK': { nama: 'Pendidikan Jasmani', file: 'pjok.html', color: '#f3e5f5' },
      'AGAMA': { nama: 'Pendidikan Agama', file: 'agama.html', color: '#e8f5e8' },
      'MULOK': { nama: 'Muatan Lokal', file: 'mulok.html', color: '#f1f8e9' }
    };

    const mapel = mapelData[mapelKode];
    if (!mapel) {
      throw new Error(`Mapel dengan kode ${mapelKode} tidak ditemukan`);
    }

    // Buat window baru untuk mapel
    const mapelWindow = new BrowserWindow({
      width: 1400,
      height: 900,
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false,
        enableRemoteModule: true
      },
      parent: mainWindow,
      modal: false,
      show: false,
      title: `Penilaian ${mapel.nama}`
    });

    mapelWindow.loadFile(path.join(__dirname, '../../refrensi/mapel', mapel.file));

    mapelWindow.once('ready-to-show', () => {
      mapelWindow.show();
    });

    mapelWindow.on('closed', () => {
      // Window akan dihapus otomatis
    });

    return { success: true, message: `Window ${mapel.nama} berhasil dibuka` };
  } catch (error) {
    console.error('Error opening mapel window:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-mapel-data', async () => {
  try {
    const mapelData = await db.getMapelData();
    return { success: true, data: mapelData };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('save-student-data', async (event, studentData) => {
  try {
    const result = await db.saveStudentData(studentData);
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-student-data', async (event, studentId) => {
  try {
    const studentData = await db.getStudentData(studentId);
    return { success: true, data: studentData };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('delete-student-data', async (event, studentId) => {
  try {
    const result = await db.deleteStudentData(studentId);
    return result;
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('update-student-data', async (event, studentId, studentData) => {
  try {
    const result = await db.updateStudentData(studentId, studentData);
    return result;
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-all-students', async () => {
  try {
    const students = await db.getAllStudents();
    return { success: true, data: students };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('search-students', async (event, searchTerm) => {
  try {
    const students = await db.searchStudents(searchTerm);
    return { success: true, data: students };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('save-nilai-data', async (event, nilaiData) => {
  try {
    const result = await db.saveNilai(nilaiData);
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-nilai-by-siswa', async (event, siswaId) => {
  try {
    const nilaiData = await db.getNilaiBySiswa(siswaId);
    return { success: true, data: nilaiData };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('save-propela-data', async (event, propelaData) => {
  try {
    const result = await db.savePropela(propelaData);
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-propela-by-siswa', async (event, siswaId) => {
  try {
    const propelaData = await db.getPropelaBySiswa(siswaId);
    return { success: true, data: propelaData };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('save-catatan-data', async (event, catatanData) => {
  try {
    const result = await db.saveCatatan(catatanData);
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-catatan-by-siswa', async (event, siswaId) => {
  try {
    const catatanData = await db.getCatatanBySiswa(siswaId);
    return { success: true, data: catatanData };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-sekolah-data', async () => {
  try {
    const sekolahData = await db.getSekolahData();
    return { success: true, data: sekolahData };
  } catch (error) {
    return { success: false, error: error.message };
  }
}); 

// IPC handlers untuk integrasi HTML
ipcMain.handle('get-all-mapel-files', async () => {
  try {
    const mapelFiles = await db.getAllMapelFiles();
    return { success: true, data: mapelFiles };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-main-files', async () => {
  try {
    const mainFiles = await db.getMainFiles();
    return { success: true, data: mainFiles };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-file-by-mapel', async (event, mapelKode) => {
  try {
    const file = await db.getFileByMapel(mapelKode);
    return { success: true, data: file };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('save-nilai-from-html', async (event, { mapelKode, siswaId, nilaiData }) => {
  try {
    const result = await db.saveNilaiFromHTML(mapelKode, siswaId, nilaiData);
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-nilai-by-mapel-and-siswa', async (event, { mapelKode, siswaId }) => {
  try {
    const nilai = await db.getNilaiByMapelAndSiswa(mapelKode, siswaId);
    return { success: true, data: nilai };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-all-nilai-by-siswa', async (event, siswaId) => {
  try {
    const nilai = await db.getAllNilaiBySiswa(siswaId);
    return { success: true, data: nilai };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('update-file-metadata', async (event, { fileId, metadata }) => {
  try {
    await db.updateFileMetadata(fileId, metadata);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-file-metadata', async (event, fileId) => {
  try {
    const metadata = await db.getFileMetadata(fileId);
    return { success: true, data: metadata };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('validate-html-integration', async () => {
  try {
    const validation = await db.validateHTMLIntegration();
    return { success: true, data: validation };
  } catch (error) {
    return { success: false, error: error.message };
  }
}); 

// API endpoints untuk HTML integration
ipcMain.handle('api-get-students', async () => {
  try {
    const students = await db.getAllStudents();
    return { success: true, data: students };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('api-get-nilai-by-mapel', async (event, { mapelKode, siswaId, semester, tahunAjaran }) => {
  try {
    const nilai = await db.getNilaiByMapelAndSiswaWithFilter(mapelKode, siswaId, semester, tahunAjaran);
    return { success: true, data: nilai };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('api-save-nilai', async (event, { mapelKode, siswaId, nilaiData }) => {
  try {
    const result = await db.saveNilaiFromHTML(mapelKode, siswaId, nilaiData);
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('api-get-propela-by-siswa', async (event, { siswaId, semester, tahunAjaran }) => {
  try {
    const propela = await db.getPropelaBySiswa(siswaId);
    if (propela && propela.semester === semester && propela.tahun_ajaran === tahunAjaran) {
      return { success: true, data: propela };
    } else {
      return { success: true, data: null };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('api-save-propela', async (event, { siswaId, propelaData }) => {
  try {
    const result = await db.savePropela({ siswa_id: siswaId, ...propelaData });
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('api-get-catatan-by-siswa', async (event, { siswaId, semester, tahunAjaran }) => {
  try {
    const catatan = await db.getCatatanBySiswa(siswaId);
    if (catatan && catatan.semester === semester && catatan.tahun_ajaran === tahunAjaran) {
      return { success: true, data: catatan };
    } else {
      return { success: true, data: null };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('api-save-catatan', async (event, { siswaId, catatanData }) => {
  try {
    const result = await db.saveCatatan({ siswa_id: siswaId, ...catatanData });
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('api-get-student-by-id', async (event, siswaId) => {
  try {
    const student = await db.getStudentData(siswaId);
    return { success: true, data: student };
  } catch (error) {
    return { success: false, error: error.message };
  }
}); 