const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

class Database {
  constructor() {
    // Pastikan folder data ada
    const dataDir = path.join(__dirname, '../../data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    this.dbPath = path.join(dataDir, 'appraport.db');
    this.db = null;
  }

  async initialize() {
    return new Promise((resolve, reject) => {
      try {
        // Pastikan folder data ada sebelum membuat database
        const dataDir = path.dirname(this.dbPath);
        if (!fs.existsSync(dataDir)) {
          fs.mkdirSync(dataDir, { recursive: true });
        }

        this.db = new sqlite3.Database(this.dbPath, (err) => {
          if (err) {
            console.error('Database initialization error:', err);
            reject(err);
            return;
          }
          console.log('Database initialized successfully at:', this.dbPath);
          this.createTables().then(resolve).catch(reject);
        });
      } catch (error) {
        console.error('Error in database initialization:', error);
        reject(error);
      }
    });
  }

  async createTables() {
    const tables = [
      `CREATE TABLE IF NOT EXISTS Kategori (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL UNIQUE,
        deskripsi TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      `CREATE TABLE IF NOT EXISTS Mapel (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kategori_id INTEGER,
        kode TEXT NOT NULL UNIQUE,
        nama TEXT NOT NULL,
        deskripsi TEXT,
        fase TEXT,
        semester INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (kategori_id) REFERENCES Kategori(id)
      )`,

      `CREATE TABLE IF NOT EXISTS Siswa (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nisn TEXT UNIQUE,
        nomor_induk TEXT,
        nama TEXT NOT NULL,
        kelas TEXT,
        fase TEXT,
        semester INTEGER,
        tahun_ajaran TEXT,
        jenis_kelamin TEXT,
        tempat_lahir TEXT,
        tanggal_lahir DATE,
        agama TEXT,
        anak_ke INTEGER,
        status_anak TEXT,
        alamat TEXT,
        no_telepon TEXT,
        tanggal_diterima DATE,
        diterima_sebagai TEXT,
        sekolah_asal TEXT,
        nama_ayah TEXT,
        nama_ibu TEXT,
        pekerjaan_ayah TEXT,
        pekerjaan_ibu TEXT,
        alamat_ortu TEXT,
        kelurahan_ortu TEXT,
        kecamatan_ortu TEXT,
        kota_ortu TEXT,
        no_telepon_ortu TEXT,
        ttd_rapor TEXT,
        nama_wali TEXT,
        no_telepon_wali TEXT,
        pekerjaan_wali TEXT,
        nama_panggilan TEXT,
        catatan1 TEXT,
        catatan2 TEXT,
        catatan3 TEXT,
        nama_kegiatan TEXT,
        predikat TEXT,
        keterangan_kegiatan TEXT,
        izin INTEGER DEFAULT 0,
        sakit INTEGER DEFAULT 0,
        alfa INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      `CREATE TABLE IF NOT EXISTS File (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mapel_id INTEGER,
        nama_file TEXT NOT NULL,
        path_file TEXT NOT NULL,
        tipe_file TEXT,
        ukuran INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (mapel_id) REFERENCES Mapel(id)
      )`,

      `CREATE TABLE IF NOT EXISTS Metadata (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_id INTEGER,
        key TEXT NOT NULL,
        value TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (file_id) REFERENCES File(id)
      )`,

      `CREATE TABLE IF NOT EXISTS Nilai (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        siswa_id INTEGER,
        mapel_id INTEGER,
        tp_1_k INTEGER,
        tp_1_t INTEGER,
        tp_2_k INTEGER,
        tp_2_t INTEGER,
        tp_3_k INTEGER,
        tp_3_t INTEGER,
        tp_4_k INTEGER,
        tp_4_t INTEGER,
        tp_5_k INTEGER,
        tp_5_t INTEGER,
        tp_6_k INTEGER,
        tp_6_t INTEGER,
        tp_7_k INTEGER,
        tp_7_t INTEGER,
        tp_8_k INTEGER,
        tp_8_t INTEGER,
        tp_9_k INTEGER,
        tp_9_t INTEGER,
        tp_10_k INTEGER,
        tp_10_t INTEGER,
        ns_1 INTEGER,
        ns_2 INTEGER,
        ns_3 INTEGER,
        ns_4 INTEGER,
        ns_5 INTEGER,
        ns_6 INTEGER,
        ns_7 INTEGER,
        ns_8 INTEGER,
        ns_9 INTEGER,
        ns_10 INTEGER,
        nilai_rapor INTEGER,
        capaian_kompetensi TEXT,
        semester INTEGER,
        tahun_ajaran TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (siswa_id) REFERENCES Siswa(id),
        FOREIGN KEY (mapel_id) REFERENCES Mapel(id)
      )`,

      `CREATE TABLE IF NOT EXISTS Propela (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        siswa_id INTEGER,
        beriman_mb INTEGER DEFAULT 0,
        beriman_sb INTEGER DEFAULT 0,
        beriman_bsh INTEGER DEFAULT 0,
        beriman_sab INTEGER DEFAULT 0,
        berkebhinekaan_mb INTEGER DEFAULT 0,
        berkebhinekaan_sb INTEGER DEFAULT 0,
        berkebhinekaan_bsh INTEGER DEFAULT 0,
        berkebhinekaan_sab INTEGER DEFAULT 0,
        bergotong_mb INTEGER DEFAULT 0,
        bergotong_sb INTEGER DEFAULT 0,
        bergotong_bsh INTEGER DEFAULT 0,
        bergotong_sab INTEGER DEFAULT 0,
        mandiri_mb INTEGER DEFAULT 0,
        mandiri_sb INTEGER DEFAULT 0,
        mandiri_bsh INTEGER DEFAULT 0,
        mandiri_sab INTEGER DEFAULT 0,
        bernalar_mb INTEGER DEFAULT 0,
        bernalar_sb INTEGER DEFAULT 0,
        bernalar_bsh INTEGER DEFAULT 0,
        bernalar_sab INTEGER DEFAULT 0,
        kreatif_mb INTEGER DEFAULT 0,
        kreatif_sb INTEGER DEFAULT 0,
        kreatif_bsh INTEGER DEFAULT 0,
        kreatif_sab INTEGER DEFAULT 0,
        catatan_proses TEXT,
        semester INTEGER,
        tahun_ajaran TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (siswa_id) REFERENCES Siswa(id)
      )`,

      `CREATE TABLE IF NOT EXISTS Catatan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        siswa_id INTEGER,
        catatan_profil TEXT,
        catatan_pemberdayaan TEXT,
        catatan_keterampilan TEXT,
        semester INTEGER,
        tahun_ajaran TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (siswa_id) REFERENCES Siswa(id)
      )`,

      `CREATE TABLE IF NOT EXISTS Sekolah (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        npsn TEXT,
        alamat TEXT,
        desa_kelurahan TEXT,
        kecamatan TEXT,
        kabupaten_kota TEXT,
        provinsi TEXT,
        kode_pos TEXT,
        telepon TEXT,
        website TEXT,
        email TEXT,
        kepala_sekolah TEXT,
        nip_kepala_sekolah TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    for (const table of tables) {
      await this.run(table);
    }

    await this.insertInitialData();
  }

  async insertInitialData() {
    const kategoriData = [
      { nama: 'Muatan Nasional', deskripsi: 'Mata pelajaran wajib nasional' },
      { nama: 'Muatan Lokal', deskripsi: 'Mata pelajaran muatan lokal' },
      { nama: 'Muatan Keterampilan', deskripsi: 'Mata pelajaran keterampilan' }
    ];

    for (const kategori of kategoriData) {
      await this.run(
        'INSERT OR IGNORE INTO Kategori (nama, deskripsi) VALUES (?, ?)',
        [kategori.nama, kategori.deskripsi]
      );
    }

    const mapelData = [
      { kode: 'MTK', nama: 'Matematika', kategori: 'Muatan Nasional', fase: 'B', file: 'mtk.html' },
      { kode: 'BINDO', nama: 'Bahasa Indonesia', kategori: 'Muatan Nasional', fase: 'B', file: 'bindo.html' },
      { kode: 'BINGGRIS', nama: 'Bahasa Inggris', kategori: 'Muatan Nasional', fase: 'B', file: 'bInggris.html' },
      { kode: 'PKN', nama: 'Pendidikan Kewarganegaraan', kategori: 'Muatan Nasional', fase: 'B', file: 'pkn.html' },
      { kode: 'IPS', nama: 'Ilmu Pengetahuan Sosial', kategori: 'Muatan Nasional', fase: 'B', file: 'Ips.html' },
      { kode: 'SBD', nama: 'Seni Budaya', kategori: 'Muatan Nasional', fase: 'B', file: 'sbd.html' },
      { kode: 'PJOK', nama: 'Pendidikan Jasmani', kategori: 'Muatan Nasional', fase: 'B', file: 'pjok.html' },
      { kode: 'AGAMA', nama: 'Pendidikan Agama', kategori: 'Muatan Nasional', fase: 'B', file: 'agama.html' },
      { kode: 'MULOK', nama: 'Muatan Lokal', kategori: 'Muatan Lokal', fase: 'B', file: 'mulok.html' }
    ];

    for (const mapel of mapelData) {
      const kategoriId = await this.get('SELECT id FROM Kategori WHERE nama = ?', [mapel.kategori]);
      if (kategoriId) {
        const result = await this.run(
          'INSERT OR IGNORE INTO Mapel (kode, nama, kategori_id, fase) VALUES (?, ?, ?, ?)',
          [mapel.kode, mapel.nama, kategoriId.id, mapel.fase]
        );
        
        // Simpan referensi file HTML
        if (result.changes > 0) {
          const mapelId = await this.get('SELECT id FROM Mapel WHERE kode = ?', [mapel.kode]);
          if (mapelId) {
            await this.run(
              'INSERT OR IGNORE INTO File (mapel_id, nama_file, path_file, tipe_file) VALUES (?, ?, ?, ?)',
              [mapelId.id, mapel.file, `refrensi/mapel/${mapel.file}`, 'html']
            );
          }
        }
      }
    }

    // Simpan referensi file HTML utama
    const mainFiles = [
      { nama: 'presdik.html', path: 'refrensi/presdik.html', tipe: 'html' },
      { nama: 'nilaitp.html', path: 'refrensi/nilaitp.html', tipe: 'html' },
      { nama: 'propela.html', path: 'refrensi/propela.html', tipe: 'html' },
      { nama: 'catatan.html', path: 'refrensi/catatan.html', tipe: 'html' }
    ];

    for (const file of mainFiles) {
      await this.run(
        'INSERT OR IGNORE INTO File (nama_file, path_file, tipe_file) VALUES (?, ?, ?)',
        [file.nama, file.path, file.tipe]
      );
    }

    const sekolahData = {
      nama: 'SPNF-SKB 27 JAKARTA',
      npsn: 'P2966648',
      alamat: 'Jl. Kemajuan Raya No.27, RT.7/RW.4',
      desa_kelurahan: 'Petukangan Selatan',
      kecamatan: 'Kec. Pesanggrahan',
      kabupaten_kota: 'Kota Jakarta Selatan',
      provinsi: 'Provinsi DKI Jakarta',
      kode_pos: '12270',
      telepon: '(021) 73887103',
      kepala_sekolah: 'Ir. Harum Mawar I.W., M.Pd.',
      nip_kepala_sekolah: '196705231998032001'
    };

    await this.run(
      `INSERT OR IGNORE INTO Sekolah (
        nama, npsn, alamat, desa_kelurahan, kecamatan, kabupaten_kota, 
        provinsi, kode_pos, telepon, kepala_sekolah, nip_kepala_sekolah
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(sekolahData)
    );
  }

  async run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, changes: this.changes });
      });
    });
  }

  async get(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  async all(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  async getMapelData() {
    const sql = `
      SELECT m.*, k.nama as kategori_nama 
      FROM Mapel m 
      LEFT JOIN Kategori k ON m.kategori_id = k.id 
      ORDER BY m.kode
    `;
    return await this.all(sql);
  }

  async saveStudentData(studentData) {
    const result = await this.run(
      `INSERT OR REPLACE INTO Siswa (
        nisn, nomor_induk, nama, kelas, fase, semester, tahun_ajaran,
        jenis_kelamin, tempat_lahir, tanggal_lahir, agama, anak_ke, status_anak,
        alamat, no_telepon, tanggal_diterima, diterima_sebagai, sekolah_asal,
        nama_ayah, nama_ibu, pekerjaan_ayah, pekerjaan_ibu, alamat_ortu,
        kelurahan_ortu, kecamatan_ortu, kota_ortu, no_telepon_ortu, ttd_rapor,
        nama_wali, no_telepon_wali, pekerjaan_wali, nama_panggilan, catatan1,
        catatan2, catatan3, nama_kegiatan, predikat, keterangan_kegiatan, izin,
        sakit, alfa
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        studentData.nisn, studentData.nomor_induk, studentData.nama, studentData.kelas, 
        studentData.fase, studentData.semester, studentData.tahun_ajaran, studentData.jenis_kelamin, 
        studentData.tempat_lahir, studentData.tanggal_lahir, studentData.agama, studentData.anak_ke, 
        studentData.status_anak, studentData.alamat, studentData.no_telepon, studentData.tanggal_diterima, 
        studentData.diterima_sebagai, studentData.sekolah_asal, studentData.nama_ayah, studentData.nama_ibu, 
        studentData.pekerjaan_ayah, studentData.pekerjaan_ibu, studentData.alamat_ortu, 
        studentData.kelurahan_ortu, studentData.kecamatan_ortu, studentData.kota_ortu, 
        studentData.no_telepon_ortu, studentData.ttd_rapor, studentData.nama_wali, 
        studentData.no_telepon_wali, studentData.pekerjaan_wali, studentData.nama_panggilan, 
        studentData.catatan1, studentData.catatan2, studentData.catatan3, studentData.nama_kegiatan, 
        studentData.predikat, studentData.keterangan_kegiatan, studentData.izin, studentData.sakit, 
        studentData.alfa
      ]
    );
    
    return result;
  }

  async getStudentData(studentId) {
    return await this.get('SELECT * FROM Siswa WHERE id = ?', [studentId]);
  }

  async deleteStudentData(studentId) {
    try {
      // Hapus data terkait terlebih dahulu
      await this.run('DELETE FROM Nilai WHERE siswa_id = ?', [studentId]);
      await this.run('DELETE FROM Propela WHERE siswa_id = ?', [studentId]);
      await this.run('DELETE FROM Catatan WHERE siswa_id = ?', [studentId]);
      
      // Hapus data siswa
      const result = await this.run('DELETE FROM Siswa WHERE id = ?', [studentId]);
      return { success: true, changes: result.changes };
    } catch (error) {
      console.error('Error deleting student:', error);
      return { success: false, error: error.message };
    }
  }

  async updateStudentData(studentId, studentData) {
    try {
      const result = await this.run(
        `UPDATE Siswa SET 
          nisn = ?, nomor_induk = ?, nama = ?, kelas = ?, fase = ?, semester = ?, 
          tahun_ajaran = ?, jenis_kelamin = ?, tempat_lahir = ?, tanggal_lahir = ?, 
          agama = ?, anak_ke = ?, status_anak = ?, alamat = ?, no_telepon = ?, 
          tanggal_diterima = ?, diterima_sebagai = ?, sekolah_asal = ?, 
          nama_ayah = ?, nama_ibu = ?, pekerjaan_ayah = ?, pekerjaan_ibu = ?, 
          alamat_ortu = ?, kelurahan_ortu = ?, kecamatan_ortu = ?, kota_ortu = ?, 
          no_telepon_ortu = ?, ttd_rapor = ?, nama_wali = ?, no_telepon_wali = ?,
          pekerjaan_wali = ?, nama_panggilan = ?, catatan1 = ?, catatan2 = ?, 
          catatan3 = ?, nama_kegiatan = ?, predikat = ?, keterangan_kegiatan = ?, 
          izin = ?, sakit = ?, alfa = ?
        WHERE id = ?`,
        [
          studentData.nisn, studentData.nomor_induk, studentData.nama, studentData.kelas,
          studentData.fase, studentData.semester, studentData.tahun_ajaran, studentData.jenis_kelamin,
          studentData.tempat_lahir, studentData.tanggal_lahir, studentData.agama, studentData.anak_ke,
          studentData.status_anak, studentData.alamat, studentData.no_telepon, studentData.tanggal_diterima,
          studentData.diterima_sebagai, studentData.sekolah_asal, studentData.nama_ayah, studentData.nama_ibu,
          studentData.pekerjaan_ayah, studentData.pekerjaan_ibu, studentData.alamat_ortu, studentData.kelurahan_ortu,
          studentData.kecamatan_ortu, studentData.kota_ortu, studentData.no_telepon_ortu, studentData.ttd_rapor,
          studentData.nama_wali, studentData.no_telepon_wali, studentData.pekerjaan_wali, studentData.nama_panggilan,
          studentData.catatan1, studentData.catatan2, studentData.catatan3, studentData.nama_kegiatan,
          studentData.predikat, studentData.keterangan_kegiatan, studentData.izin, studentData.sakit,
          studentData.alfa, studentId
        ]
      );
      return { success: true, changes: result.changes };
    } catch (error) {
      console.error('Error updating student:', error);
      return { success: false, error: error.message };
    }
  }

  async getAllStudents() {
    return await this.all('SELECT * FROM Siswa ORDER BY nama');
  }

  async saveNilai(nilaiData) {
    const result = await this.run(
      `INSERT OR REPLACE INTO Nilai (
        siswa_id, mapel_id, tp_1_k, tp_1_t, tp_2_k, tp_2_t, tp_3_k, tp_3_t, tp_4_k, tp_4_t,
        tp_5_k, tp_5_t, tp_6_k, tp_6_t, tp_7_k, tp_7_t, tp_8_k, tp_8_t, tp_9_k, tp_9_t,
        tp_10_k, tp_10_t, ns_1, ns_2, ns_3, ns_4, ns_5, ns_6, ns_7, ns_8, ns_9, ns_10,
        nilai_rapor, capaian_kompetensi, semester, tahun_ajaran
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(nilaiData)
    );
    
    return result;
  }

  async getNilaiBySiswa(siswaId) {
    const sql = `
      SELECT n.*, m.nama as mapel_nama, m.kode as mapel_kode
      FROM Nilai n
      LEFT JOIN Mapel m ON n.mapel_id = m.id
      WHERE n.siswa_id = ?
    `;
    return await this.all(sql, [siswaId]);
  }

  async savePropela(propelaData) {
    const result = await this.run(
      `INSERT OR REPLACE INTO Propela (
        siswa_id, beriman_mb, beriman_sb, beriman_bsh, beriman_sab,
        berkebhinekaan_mb, berkebhinekaan_sb, berkebhinekaan_bsh, berkebhinekaan_sab,
        bergotong_mb, bergotong_sb, bergotong_bsh, bergotong_sab,
        mandiri_mb, mandiri_sb, mandiri_bsh, mandiri_sab,
        bernalar_mb, bernalar_sb, bernalar_bsh, bernalar_sab,
        kreatif_mb, kreatif_sb, kreatif_bsh, kreatif_sab,
        catatan_proses, semester, tahun_ajaran
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(propelaData)
    );
    
    return result;
  }

  async getPropelaBySiswa(siswaId) {
    return await this.get('SELECT * FROM Propela WHERE siswa_id = ?', [siswaId]);
  }

  async saveCatatan(catatanData) {
    const result = await this.run(
      `INSERT OR REPLACE INTO Catatan (
        siswa_id, catatan_profil, catatan_pemberdayaan, catatan_keterampilan,
        semester, tahun_ajaran
      ) VALUES (?, ?, ?, ?, ?, ?)`,
      Object.values(catatanData)
    );
    
    return result;
  }

  async getCatatanBySiswa(siswaId) {
    return await this.get('SELECT * FROM Catatan WHERE siswa_id = ?', [siswaId]);
  }

  async getSekolahData() {
    return await this.get('SELECT * FROM Sekolah LIMIT 1');
  }

  async searchStudents(searchTerm) {
    const sql = `
      SELECT * FROM Siswa 
      WHERE nama LIKE ? OR nisn LIKE ? OR nomor_induk LIKE ?
      ORDER BY nama
    `;
    const searchPattern = `%${searchTerm}%`;
    return await this.all(sql, [searchPattern, searchPattern, searchPattern]);
  }

  // Fungsi baru untuk integrasi HTML
  async getFileByMapel(mapelKode) {
    const sql = `
      SELECT f.* FROM File f
      JOIN Mapel m ON f.mapel_id = m.id
      WHERE m.kode = ? AND f.tipe_file = 'html'
    `;
    return await this.get(sql, [mapelKode]);
  }

  async getAllMapelFiles() {
    const sql = `
      SELECT m.kode, m.nama, f.nama_file, f.path_file
      FROM Mapel m
      LEFT JOIN File f ON m.id = f.mapel_id
      WHERE f.tipe_file = 'html'
      ORDER BY m.kode
    `;
    return await this.all(sql);
  }

  async getMainFiles() {
    const sql = `
      SELECT nama_file, path_file, tipe_file
      FROM File
      WHERE mapel_id IS NULL AND tipe_file = 'html'
      ORDER BY nama_file
    `;
    return await this.all(sql);
  }

  async saveNilaiFromHTML(mapelKode, siswaId, nilaiData) {
    const mapel = await this.get('SELECT id FROM Mapel WHERE kode = ?', [mapelKode]);
    if (!mapel) {
      throw new Error(`Mapel dengan kode ${mapelKode} tidak ditemukan`);
    }

    // Pastikan semester dan tahun_ajaran ada dalam data
    if (!nilaiData.semester || !nilaiData.tahun_ajaran) {
      throw new Error('Semester dan tahun ajaran harus diisi');
    }

    // Cek apakah data sudah ada
    const existingData = await this.get(
      'SELECT id FROM Nilai WHERE siswa_id = ? AND mapel_id = ? AND semester = ? AND tahun_ajaran = ?',
      [siswaId, mapel.id, nilaiData.semester, nilaiData.tahun_ajaran]
    );

    const data = {
      siswa_id: siswaId,
      mapel_id: mapel.id,
      ...nilaiData
    };

    if (existingData) {
      // Update data yang sudah ada
      const updateFields = [];
      const updateValues = [];
      
      // Tambahkan semua field kecuali id
      Object.keys(data).forEach(key => {
        if (key !== 'id') {
          updateFields.push(`${key} = ?`);
          updateValues.push(data[key]);
        }
      });
      
      // Tambahkan kondisi WHERE
      updateValues.push(existingData.id);
      
      const updateSql = `UPDATE Nilai SET ${updateFields.join(', ')} WHERE id = ?`;
      const result = await this.run(updateSql, updateValues);
      
      console.log(`Updated nilai for siswa ${siswaId}, mapel ${mapelKode}, semester ${nilaiData.semester}`);
      return { ...result, action: 'updated', id: existingData.id };
    } else {
      // Insert data baru
      const result = await this.saveNilai(data);
      console.log(`Inserted new nilai for siswa ${siswaId}, mapel ${mapelKode}, semester ${nilaiData.semester}`);
      return { ...result, action: 'inserted' };
    }
  }

  async getNilaiByMapelAndSiswa(mapelKode, siswaId) {
    const sql = `
      SELECT n.*, m.nama as mapel_nama, m.kode as mapel_kode
      FROM Nilai n
      JOIN Mapel m ON n.mapel_id = m.id
      WHERE m.kode = ? AND n.siswa_id = ?
    `;
    return await this.get(sql, [mapelKode, siswaId]);
  }

  async getNilaiByMapelAndSiswaWithFilter(mapelKode, siswaId, semester, tahunAjaran) {
    const sql = `
      SELECT n.*, m.nama as mapel_nama, m.kode as mapel_kode
      FROM Nilai n
      JOIN Mapel m ON n.mapel_id = m.id
      WHERE m.kode = ? AND n.siswa_id = ? AND n.semester = ? AND n.tahun_ajaran = ?
    `;
    return await this.get(sql, [mapelKode, siswaId, semester, tahunAjaran]);
  }

  async getAllNilaiBySiswa(siswaId) {
    const sql = `
      SELECT n.*, m.nama as mapel_nama, m.kode as mapel_kode
      FROM Nilai n
      JOIN Mapel m ON n.mapel_id = m.id
      WHERE n.siswa_id = ?
      ORDER BY m.kode
    `;
    return await this.all(sql, [siswaId]);
  }

  async updateFileMetadata(fileId, metadata) {
    for (const [key, value] of Object.entries(metadata)) {
      await this.run(
        'INSERT OR REPLACE INTO Metadata (file_id, key, value) VALUES (?, ?, ?)',
        [fileId, key, value]
      );
    }
  }

  async getFileMetadata(fileId) {
    const sql = 'SELECT key, value FROM Metadata WHERE file_id = ?';
    const rows = await this.all(sql, [fileId]);
    const metadata = {};
    rows.forEach(row => {
      metadata[row.key] = row.value;
    });
    return metadata;
  }

  async validateHTMLIntegration() {
    const results = {
      mapelFiles: [],
      mainFiles: [],
      errors: []
    };

    try {
      // Cek file mapel
      const mapelFiles = await this.getAllMapelFiles();
      results.mapelFiles = mapelFiles;

      // Cek file utama
      const mainFiles = await this.getMainFiles();
      results.mainFiles = mainFiles;

      // Validasi struktur
      const expectedMapel = ['MTK', 'BINDO', 'BINGGRIS', 'PKN', 'IPS', 'SBD', 'PJOK', 'AGAMA', 'MULOK'];
      const foundMapel = mapelFiles.map(f => f.kode);
      
      for (const expected of expectedMapel) {
        if (!foundMapel.includes(expected)) {
          results.errors.push(`Mapel ${expected} tidak ditemukan dalam database`);
        }
      }

      const expectedMainFiles = ['presdik.html', 'nilaitp.html', 'propela.html', 'catatan.html'];
      const foundMainFiles = mainFiles.map(f => f.nama_file);
      
      for (const expected of expectedMainFiles) {
        if (!foundMainFiles.includes(expected)) {
          results.errors.push(`File utama ${expected} tidak ditemukan dalam database`);
        }
      }

    } catch (error) {
      results.errors.push(`Error validasi: ${error.message}`);
    }

    return results;
  }

  close() {
    if (this.db) {
      this.db.close();
    }
  }
}

module.exports = Database;