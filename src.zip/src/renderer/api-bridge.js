// API Bridge untuk menghubungkan HTML dengan IPC handlers
let ipcRenderer;

// Check if we're in Electron context
if (typeof require !== 'undefined') {
  try {
    ipcRenderer = require('electron').ipcRenderer;
  } catch (error) {
    console.warn('Electron not available, using fallback mode');
  }
}

// Global API object untuk digunakan di HTML
window.AppRaportAPI = {
  // Students API
  async getStudents() {
    try {
      if (!ipcRenderer) {
        throw new Error('IPC not available - not running in Electron');
      }
      const result = await ipcRenderer.invoke('api-get-students');
      return result;
    } catch (error) {
      console.error('Error getting students:', error);
      return { success: false, error: error.message };
    }
  },

  async getStudentById(siswaId) {
    try {
      if (!ipcRenderer) {
        throw new Error('IPC not available - not running in Electron');
      }
      const result = await ipcRenderer.invoke('api-get-student-by-id', siswaId);
      return result;
    } catch (error) {
      console.error('Error getting student by ID:', error);
      return { success: false, error: error.message };
    }
  },

  // Nilai API
  async getNilaiByMapel(mapelKode, siswaId, semester, tahunAjaran) {
    try {
      if (!ipcRenderer) {
        throw new Error('IPC not available - not running in Electron');
      }
      const result = await ipcRenderer.invoke('api-get-nilai-by-mapel', {
        mapelKode,
        siswaId,
        semester,
        tahunAjaran
      });
      return result;
    } catch (error) {
      console.error('Error getting nilai by mapel:', error);
      return { success: false, error: error.message };
    }
  },

  async saveNilai(mapelKode, siswaId, nilaiData) {
    try {
      if (!ipcRenderer) {
        throw new Error('IPC not available - not running in Electron');
      }
      const result = await ipcRenderer.invoke('api-save-nilai', {
        mapelKode,
        siswaId,
        nilaiData
      });
      return result;
    } catch (error) {
      console.error('Error saving nilai:', error);
      return { success: false, error: error.message };
    }
  },

  // Propela API
  async getPropelaBySiswa(siswaId, semester, tahunAjaran) {
    try {
      if (!ipcRenderer) {
        throw new Error('IPC not available - not running in Electron');
      }
      const result = await ipcRenderer.invoke('api-get-propela-by-siswa', {
        siswaId,
        semester,
        tahunAjaran
      });
      return result;
    } catch (error) {
      console.error('Error getting propela by siswa:', error);
      return { success: false, error: error.message };
    }
  },

  async savePropela(siswaId, propelaData) {
    try {
      if (!ipcRenderer) {
        throw new Error('IPC not available - not running in Electron');
      }
      const result = await ipcRenderer.invoke('api-save-propela', {
        siswaId,
        propelaData
      });
      return result;
    } catch (error) {
      console.error('Error saving propela:', error);
      return { success: false, error: error.message };
    }
  },

  // Catatan API
  async getCatatanBySiswa(siswaId, semester, tahunAjaran) {
    try {
      if (!ipcRenderer) {
        throw new Error('IPC not available - not running in Electron');
      }
      const result = await ipcRenderer.invoke('api-get-catatan-by-siswa', {
        siswaId,
        semester,
        tahunAjaran
      });
      return result;
    } catch (error) {
      console.error('Error getting catatan by siswa:', error);
      return { success: false, error: error.message };
    }
  },

  async saveCatatan(siswaId, catatanData) {
    try {
      if (!ipcRenderer) {
        throw new Error('IPC not available - not running in Electron');
      }
      const result = await ipcRenderer.invoke('api-save-catatan', {
        siswaId,
        catatanData
      });
      return result;
    } catch (error) {
      console.error('Error saving catatan:', error);
      return { success: false, error: error.message };
    }
  },

  // Utility functions
  showNotification(type, message) {
    // Menggunakan SweetAlert jika tersedia
    if (typeof Swal !== 'undefined') {
      Swal.fire({
        icon: type,
        title: type === 'success' ? 'Berhasil!' : type === 'error' ? 'Error!' : 'Informasi',
        text: message,
        timer: type === 'success' ? 2000 : 3000,
        timerProgressBar: true,
        toast: true,
        position: 'top-end',
        showConfirmButton: false
      });
    } else {
      // Fallback ke alert biasa
      alert(`${type.toUpperCase()}: ${message}`);
    }
  },

  showSuccess(message) {
    this.showNotification('success', message);
  },

  showError(message) {
    this.showNotification('error', message);
  },

  showInfo(message) {
    this.showNotification('info', message);
  }
};

// Polyfill untuk fetch API jika tidak tersedia
if (typeof fetch === 'undefined') {
  window.fetch = async (url, options = {}) => {
    // Parse URL untuk menentukan endpoint
    const urlParts = url.split('/');
    const endpoint = urlParts[urlParts.length - 1];
    
    try {
      let result;
      
      if (options.method === 'POST') {
        const body = JSON.parse(options.body);
        
        if (endpoint === 'save') {
          result = await window.AppRaportAPI.saveNilai(
            body.mapelKode,
            body.siswaId,
            body.nilaiData
          );
        }
      } else {
        // GET request
        if (endpoint === 'students') {
          result = await window.AppRaportAPI.getStudents();
        } else if (endpoint.includes('/')) {
          const [mapel, siswaId] = endpoint.split('/');
          const params = new URLSearchParams(url.split('?')[1]);
          result = await window.AppRaportAPI.getNilaiByMapel(
            mapel,
            siswaId,
            params.get('semester'),
            params.get('tahun')
          );
        }
      }
      
      return {
        json: async () => result
      };
    } catch (error) {
      return {
        json: async () => ({ success: false, error: error.message })
      };
    }
  };
}

// Check if API is ready
if (ipcRenderer) {
  console.log('AppRaport API Bridge loaded successfully in Electron context');
} else {
  console.warn('AppRaport API Bridge loaded in fallback mode (no Electron)');
} 